# Ads Client Dashboard SaaS

Ferramenta full stack para gestores de tráfego entregarem aos clientes um painel privado de acompanhamento de campanhas Meta Ads e Google Ads.

## Stack

- Frontend: React + Vite + TypeScript
- Backend: Node.js + Fastify + Prisma
- Banco: PostgreSQL
- Autenticação: JWT + bcrypt
- Multi-cliente: isolamento por `tenantId` e `clientId`
- Integrações: Meta Ads e Google Ads preparadas para OAuth/API
- Deploy: Docker Compose pronto

## Recursos entregues

- Login seguro por usuário.
- Usuários `ADMIN`, `MANAGER` e `CLIENT`.
- Cada cliente visualiza somente seus próprios resultados.
- Cadastro de clientes e usuários vinculados.
- Dashboard com investimento, impressões, alcance, cliques, CTR, CPC, CPM, conversões e campanhas.
- Endpoints para conectar contas Meta/Google.
- Sincronização de métricas por período.
- Modo demo para validar o painel antes das credenciais oficiais.
- Banco com estrutura preparada para histórico diário por campanha.

## Como rodar localmente

```bash
cp .env.example .env
docker compose up --build
```

Acesse:

- Frontend: http://localhost:5173
- API: http://localhost:3333/health

## Primeiro acesso

Depois que a API estiver rodando:

```bash
curl -X POST http://localhost:3333/auth/bootstrap \
  -H "Content-Type: application/json" \
  -d '{"tenantName":"R2R Marketing Digital","name":"Administrador","email":"admin@r2rmarketingdigital.com.br","password":"TroqueEssaSenha123"}'
```

## Rodando sem Docker

```bash
npm install
npm run prisma:generate
npm run prisma:push
npm run dev
```

## Variáveis obrigatórias

Configure no `.env`:

```env
DATABASE_URL="postgresql://postgres:postgres@localhost:5432/meta_ads_saas?schema=public"
JWT_SECRET="troque-por-uma-chave-grande"
ENCRYPTION_KEY="12345678901234567890123456789012"
WEB_ORIGIN="http://localhost:5173"
API_PORT=3333

META_GRAPH_VERSION="v20.0"
META_APP_ID=""
META_APP_SECRET=""
META_REDIRECT_URI="http://localhost:3333/integrations/meta/callback"

GOOGLE_ADS_DEVELOPER_TOKEN=""
GOOGLE_ADS_CLIENT_ID=""
GOOGLE_ADS_CLIENT_SECRET=""
GOOGLE_ADS_REDIRECT_URI="http://localhost:3333/integrations/google/callback"
GOOGLE_ADS_LOGIN_CUSTOMER_ID=""
```

## Segurança

Nunca coloque tokens, client secrets, access tokens ou refresh tokens direto no GitHub. Use `.env` no servidor.

O backend aplica isolamento obrigatório:

- `ADMIN` e `MANAGER`: acessam clientes da própria agência/tenant.
- `CLIENT`: acessa somente o `clientId` vinculado ao próprio usuário.
- Métricas, contas de anúncio e integrações sempre são filtradas pelo vínculo do cliente.

## Observação sobre “tempo real”

Meta Ads e Google Ads normalmente têm latência, limites e políticas de quota. O projeto entrega atualização sob demanda e sincronização recorrente, criando experiência de painel em tempo quase real, sem violar limites das APIs.

import bcrypt from 'bcryptjs';
import type { FastifyInstance } from 'fastify';
import { z } from 'zod';
import { Role } from '@prisma/client';
import { prisma } from '../db.js';
import { signToken, requireAuth } from '../middleware/auth.js';
import { slugify } from '../utils/slug.js';

export async function authRoutes(app: FastifyInstance) {
  app.post('/auth/bootstrap', async (request, reply) => {
    const body = z.object({ tenantName: z.string().min(2), name: z.string().min(2), email: z.string().email(), password: z.string().min(8) }).parse(request.body);
    const existing = await prisma.user.count();
    if (existing > 0) return reply.code(409).send({ message: 'Bootstrap bloqueado: já existe usuário cadastrado.' });
    const tenant = await prisma.tenant.create({ data: { name: body.tenantName, slug: slugify(body.tenantName) } });
    const passwordHash = await bcrypt.hash(body.password, 12);
    const user = await prisma.user.create({ data: { tenantId: tenant.id, name: body.name, email: body.email.toLowerCase(), passwordHash, role: Role.ADMIN } });
    const token = signToken({ sub: user.id, tenantId: tenant.id, role: user.role, clientId: user.clientId, email: user.email, name: user.name });
    return { token, user: { id: user.id, name: user.name, email: user.email, role: user.role } };
  });

  app.post('/auth/login', async (request, reply) => {
    const body = z.object({ email: z.string().email(), password: z.string().min(1) }).parse(request.body);
    const user = await prisma.user.findUnique({ where: { email: body.email.toLowerCase() }, include: { tenant: true, client: true } });
    if (!user || !(await bcrypt.compare(body.password, user.passwordHash))) {
      return reply.code(401).send({ message: 'E-mail ou senha inválidos.' });
    }
    const token = signToken({ sub: user.id, tenantId: user.tenantId, role: user.role, clientId: user.clientId, email: user.email, name: user.name });
    return { token, user: { id: user.id, name: user.name, email: user.email, role: user.role, tenant: user.tenant.name, client: user.client?.name } };
  });

  app.get('/me', { preHandler: requireAuth }, async (request) => {
    const user = await prisma.user.findUnique({ where: { id: request.user!.sub }, select: { id: true, name: true, email: true, role: true, clientId: true, tenant: { select: { name: true } }, client: { select: { name: true } } } });
    return { user };
  });
}

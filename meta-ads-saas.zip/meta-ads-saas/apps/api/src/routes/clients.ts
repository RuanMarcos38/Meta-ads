import bcrypt from 'bcryptjs';
import type { FastifyInstance } from 'fastify';
import { Role } from '@prisma/client';
import { z } from 'zod';
import { prisma } from '../db.js';
import { requireAuth, requireRoles } from '../middleware/auth.js';
import { slugify } from '../utils/slug.js';

export async function clientRoutes(app: FastifyInstance) {
  app.get('/clients', { preHandler: requireAuth }, async (request) => {
    if (request.user!.role === Role.CLIENT) {
      const client = await prisma.client.findUnique({ where: { id: request.user!.clientId! } });
      return { clients: client ? [client] : [] };
    }
    const clients = await prisma.client.findMany({ where: { tenantId: request.user!.tenantId }, orderBy: { createdAt: 'desc' } });
    return { clients };
  });

  app.post('/clients', { preHandler: requireRoles([Role.ADMIN, Role.MANAGER]) }, async (request) => {
    const body = z.object({ name: z.string().min(2), notes: z.string().optional() }).parse(request.body);
    const client = await prisma.client.create({ data: { tenantId: request.user!.tenantId, name: body.name, slug: slugify(body.name), notes: body.notes } });
    return { client };
  });

  app.post('/clients/:clientId/users', { preHandler: requireRoles([Role.ADMIN, Role.MANAGER]) }, async (request, reply) => {
    const params = z.object({ clientId: z.string() }).parse(request.params);
    const body = z.object({ name: z.string().min(2), email: z.string().email(), password: z.string().min(8), role: z.enum(['CLIENT', 'MANAGER']).default('CLIENT') }).parse(request.body);
    const client = await prisma.client.findFirst({ where: { id: params.clientId, tenantId: request.user!.tenantId } });
    if (!client) return reply.code(404).send({ message: 'Cliente não encontrado.' });
    const passwordHash = await bcrypt.hash(body.password, 12);
    const user = await prisma.user.create({ data: { tenantId: request.user!.tenantId, clientId: body.role === 'CLIENT' ? client.id : null, name: body.name, email: body.email.toLowerCase(), passwordHash, role: body.role as Role } });
    return { user: { id: user.id, name: user.name, email: user.email, role: user.role } };
  });
}

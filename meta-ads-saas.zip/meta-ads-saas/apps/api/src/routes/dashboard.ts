import type { FastifyInstance } from 'fastify';
import { Provider, Role } from '@prisma/client';
import { z } from 'zod';
import { requireAuth, resolveClientScope } from '../middleware/auth.js';
import { getDashboardSummary, syncClientMetrics } from '../services/metrics.js';

function defaultPeriod() {
  const to = new Date();
  const from = new Date();
  from.setDate(to.getDate() - 7);
  return { from, to };
}

export async function dashboardRoutes(app: FastifyInstance) {
  app.get('/dashboard/summary', { preHandler: requireAuth }, async (request) => {
    const query = z.object({ clientId: z.string().optional(), from: z.string().optional(), to: z.string().optional() }).parse(request.query);
    const period = defaultPeriod();
    const clientId = resolveClientScope(request, query.clientId);
    return getDashboardSummary({ tenantId: request.user!.tenantId, clientId, from: query.from ? new Date(query.from) : period.from, to: query.to ? new Date(query.to) : period.to });
  });

  app.post('/dashboard/sync', { preHandler: requireAuth }, async (request, reply) => {
    const body = z.object({ clientId: z.string().optional(), provider: z.enum(['META', 'GOOGLE']).optional(), from: z.string().optional(), to: z.string().optional() }).parse(request.body);
    const clientId = resolveClientScope(request, body.clientId);
    if (!clientId && request.user!.role !== Role.CLIENT) return reply.code(400).send({ message: 'Informe clientId para sincronizar.' });
    const period = defaultPeriod();
    return syncClientMetrics({ clientId: clientId!, provider: body.provider as Provider | undefined, from: body.from || period.from.toISOString().slice(0, 10), to: body.to || period.to.toISOString().slice(0, 10) });
  });
}

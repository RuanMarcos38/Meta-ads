import type { FastifyInstance } from 'fastify';
import { Provider } from '@prisma/client';
import { z } from 'zod';
import { prisma } from '../db.js';
import { env } from '../env.js';
import { requireRoles } from '../middleware/auth.js';
import { encryptSecret } from '../utils/crypto.js';

export async function integrationRoutes(app: FastifyInstance) {
  app.get('/integrations', { preHandler: requireRoles(['ADMIN', 'MANAGER'] as any) }, async (request) => {
    const connections = await prisma.providerConnection.findMany({ where: { tenantId: request.user!.tenantId }, include: { client: true }, orderBy: { createdAt: 'desc' } });
    return { connections: connections.map(c => ({ ...c, accessToken: undefined, refreshToken: undefined })) };
  });

  app.post('/integrations/manual-ad-account', { preHandler: requireRoles(['ADMIN', 'MANAGER'] as any) }, async (request, reply) => {
    const body = z.object({ clientId: z.string(), provider: z.enum(['META', 'GOOGLE']), externalId: z.string().min(2), name: z.string().min(2), currency: z.string().optional() }).parse(request.body);
    const client = await prisma.client.findFirst({ where: { id: body.clientId, tenantId: request.user!.tenantId } });
    if (!client) return reply.code(404).send({ message: 'Cliente não encontrado.' });
    const account = await prisma.adAccount.upsert({
      where: { provider_externalId_clientId: { provider: body.provider as Provider, externalId: body.externalId, clientId: body.clientId } },
      create: { clientId: body.clientId, provider: body.provider as Provider, externalId: body.externalId, name: body.name, currency: body.currency || 'BRL' },
      update: { name: body.name, currency: body.currency || 'BRL' }
    });
    return { account };
  });

  app.post('/integrations/token', { preHandler: requireRoles(['ADMIN', 'MANAGER'] as any) }, async (request, reply) => {
    const body = z.object({ clientId: z.string(), provider: z.enum(['META', 'GOOGLE']), accountExternalId: z.string().optional(), accountName: z.string().optional(), accessToken: z.string().optional(), refreshToken: z.string().optional() }).parse(request.body);
    const client = await prisma.client.findFirst({ where: { id: body.clientId, tenantId: request.user!.tenantId } });
    if (!client) return reply.code(404).send({ message: 'Cliente não encontrado.' });
    const connection = await prisma.providerConnection.create({
      data: {
        tenantId: request.user!.tenantId,
        clientId: client.id,
        provider: body.provider as Provider,
        accountExternalId: body.accountExternalId,
        accountName: body.accountName,
        accessToken: encryptSecret(body.accessToken),
        refreshToken: encryptSecret(body.refreshToken),
        status: 'ACTIVE'
      }
    });
    return { connection: { ...connection, accessToken: undefined, refreshToken: undefined } };
  });

  app.get('/integrations/meta/auth-url', { preHandler: requireRoles(['ADMIN', 'MANAGER'] as any) }, async () => {
    const url = new URL(`https://www.facebook.com/${env.META_GRAPH_VERSION}/dialog/oauth`);
    url.searchParams.set('client_id', env.META_APP_ID);
    url.searchParams.set('redirect_uri', env.META_REDIRECT_URI);
    url.searchParams.set('scope', 'ads_read,business_management');
    return { url: url.toString() };
  });

  app.get('/integrations/google/auth-url', { preHandler: requireRoles(['ADMIN', 'MANAGER'] as any) }, async () => {
    const url = new URL('https://accounts.google.com/o/oauth2/v2/auth');
    url.searchParams.set('client_id', env.GOOGLE_ADS_CLIENT_ID);
    url.searchParams.set('redirect_uri', env.GOOGLE_ADS_REDIRECT_URI);
    url.searchParams.set('response_type', 'code');
    url.searchParams.set('access_type', 'offline');
    url.searchParams.set('prompt', 'consent');
    url.searchParams.set('scope', 'https://www.googleapis.com/auth/adwords');
    return { url: url.toString() };
  });
}

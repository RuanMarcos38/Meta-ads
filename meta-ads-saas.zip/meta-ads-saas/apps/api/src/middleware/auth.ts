import type { FastifyReply, FastifyRequest } from 'fastify';
import jwt from 'jsonwebtoken';
import { Role } from '@prisma/client';
import { env } from '../env.js';

export type AuthUser = {
  sub: string;
  tenantId: string;
  role: Role;
  clientId?: string | null;
  email: string;
  name: string;
};

declare module 'fastify' {
  interface FastifyRequest {
    user?: AuthUser;
  }
}

export function signToken(user: AuthUser) {
  return jwt.sign(user, env.JWT_SECRET, { expiresIn: '8h' });
}

export async function requireAuth(request: FastifyRequest, reply: FastifyReply) {
  const header = request.headers.authorization;
  if (!header?.startsWith('Bearer ')) {
    return reply.code(401).send({ message: 'Token ausente.' });
  }
  try {
    request.user = jwt.verify(header.slice(7), env.JWT_SECRET) as AuthUser;
  } catch {
    return reply.code(401).send({ message: 'Token inválido ou expirado.' });
  }
}

export function requireRoles(roles: Role[]) {
  return async (request: FastifyRequest, reply: FastifyReply) => {
    await requireAuth(request, reply);
    if (reply.sent) return;
    if (!request.user || !roles.includes(request.user.role)) {
      return reply.code(403).send({ message: 'Acesso negado.' });
    }
  };
}

export function resolveClientScope(request: FastifyRequest, requestedClientId?: string | null) {
  if (!request.user) throw new Error('Usuário não autenticado');
  if (request.user.role === Role.CLIENT) {
    if (!request.user.clientId) throw new Error('Usuário cliente sem clientId vinculado');
    return request.user.clientId;
  }
  return requestedClientId || undefined;
}

import { Provider } from '@prisma/client';

export function generateDemoCampaigns(provider: Provider, clientName: string, days = 7) {
  const today = new Date();
  const campaigns = ['Captação Leads WhatsApp', 'Remarketing Site', 'Pesquisa Alta Intenção', 'Institucional Conversões'];
  return Array.from({ length: days }).flatMap((_, dayIndex) => {
    const date = new Date(today);
    date.setDate(today.getDate() - dayIndex);
    return campaigns.map((name, index) => {
      const base = (index + 1) * 100 + dayIndex * 12;
      const clicks = base + 35;
      const impressions = base * 18;
      const spend = Number((base * (provider === Provider.META ? 0.42 : 0.56)).toFixed(2));
      const conversions = Number((clicks * (provider === Provider.META ? 0.11 : 0.08)).toFixed(2));
      return {
        date,
        campaignExternalId: `${provider.toLowerCase()}-${clientName}-${index}`,
        campaignName: `${name} - ${provider}`,
        campaignStatus: 'ACTIVE',
        impressions,
        reach: provider === Provider.META ? Math.round(impressions * 0.72) : 0,
        clicks,
        spend,
        conversions,
        ctr: impressions ? Number(((clicks / impressions) * 100).toFixed(4)) : 0,
        cpc: clicks ? Number((spend / clicks).toFixed(4)) : 0,
        cpm: impressions ? Number(((spend / impressions) * 1000).toFixed(4)) : 0,
        roas: Number((conversions * 35 / Math.max(spend, 1)).toFixed(4)),
        rawJson: { demo: true }
      };
    });
  });
}

import { Provider } from '@prisma/client';
import { prisma } from '../db.js';
import { env } from '../env.js';
import { generateDemoCampaigns } from './demoData.js';
import { fetchGoogleCampaignInsights } from './googleAds.js';
import { fetchMetaCampaignInsights, type NormalizedMetric } from './metaAds.js';

export async function syncClientMetrics(params: { clientId: string; provider?: Provider; from: string; to: string }) {
  const client = await prisma.client.findUnique({ where: { id: params.clientId }, include: { adAccounts: true } });
  if (!client) throw new Error('Cliente não encontrado.');

  const accounts = client.adAccounts.filter(a => !params.provider || a.provider === params.provider);
  const effectiveAccounts = accounts.length ? accounts : [];

  if (env.DEMO_MODE && effectiveAccounts.length === 0) {
    const meta = await prisma.adAccount.create({ data: { clientId: client.id, provider: Provider.META, externalId: `demo-meta-${client.id}`, name: 'Conta Demo Meta Ads', currency: 'BRL' } });
    const google = await prisma.adAccount.create({ data: { clientId: client.id, provider: Provider.GOOGLE, externalId: `demo-google-${client.id}`, name: 'Conta Demo Google Ads', currency: 'BRL' } });
    await saveMetrics(client.id, meta.id, Provider.META, generateDemoCampaigns(Provider.META, client.name));
    await saveMetrics(client.id, google.id, Provider.GOOGLE, generateDemoCampaigns(Provider.GOOGLE, client.name));
    return { synced: 56, mode: 'demo' };
  }

  let synced = 0;
  for (const account of effectiveAccounts) {
    const connection = account.providerConnectionId ? await prisma.providerConnection.findUnique({ where: { id: account.providerConnectionId } }) : null;
    let metrics: NormalizedMetric[] = [];
    if (env.DEMO_MODE) {
      metrics = generateDemoCampaigns(account.provider, client.name);
    } else if (account.provider === Provider.META) {
      metrics = await fetchMetaCampaignInsights({ encryptedAccessToken: connection?.accessToken, adAccountId: account.externalId, from: params.from, to: params.to });
    } else {
      metrics = await fetchGoogleCampaignInsights({ encryptedRefreshToken: connection?.refreshToken, customerId: account.externalId, from: params.from, to: params.to });
    }
    await saveMetrics(client.id, account.id, account.provider, metrics);
    synced += metrics.length;
  }
  return { synced, mode: env.DEMO_MODE ? 'demo' : 'api' };
}

async function saveMetrics(clientId: string, adAccountId: string, provider: Provider, metrics: NormalizedMetric[]) {
  for (const m of metrics) {
    await prisma.metricSnapshot.upsert({
      where: {
        provider_adAccountId_date_campaignExternalId: {
          provider,
          adAccountId,
          date: m.date,
          campaignExternalId: m.campaignExternalId
        }
      },
      create: { clientId, adAccountId, provider, ...m },
      update: { ...m, syncedAt: new Date() }
    });
  }
}

export async function getDashboardSummary(params: { tenantId: string; clientId?: string; from: Date; to: Date }) {
  const clientWhere = params.clientId ? { id: params.clientId, tenantId: params.tenantId } : { tenantId: params.tenantId };
  const clients = await prisma.client.findMany({ where: clientWhere, select: { id: true, name: true } });
  const clientIds = clients.map(c => c.id);

  const metrics = await prisma.metricSnapshot.findMany({
    where: { clientId: { in: clientIds }, date: { gte: params.from, lte: params.to } },
    orderBy: [{ date: 'desc' }, { spend: 'desc' }],
    include: { adAccount: true, client: true }
  });

  const totals = metrics.reduce((acc, m) => {
    acc.spend += Number(m.spend);
    acc.impressions += m.impressions;
    acc.reach += m.reach;
    acc.clicks += m.clicks;
    acc.conversions += Number(m.conversions);
    return acc;
  }, { spend: 0, impressions: 0, reach: 0, clicks: 0, conversions: 0 });

  const ctr = totals.impressions ? (totals.clicks / totals.impressions) * 100 : 0;
  const cpc = totals.clicks ? totals.spend / totals.clicks : 0;
  const cpm = totals.impressions ? (totals.spend / totals.impressions) * 1000 : 0;

  const campaigns = Object.values(metrics.reduce<Record<string, any>>((acc, m) => {
    const key = `${m.provider}-${m.campaignExternalId}`;
    if (!acc[key]) acc[key] = { provider: m.provider, campaignExternalId: m.campaignExternalId, campaignName: m.campaignName, clientName: m.client.name, impressions: 0, clicks: 0, spend: 0, conversions: 0 };
    acc[key].impressions += m.impressions;
    acc[key].clicks += m.clicks;
    acc[key].spend += Number(m.spend);
    acc[key].conversions += Number(m.conversions);
    return acc;
  }, {})).sort((a: any, b: any) => b.spend - a.spend);

  return { totals: { ...totals, ctr, cpc, cpm }, campaigns, clients };
}

import axios from 'axios';
import { Provider } from '@prisma/client';
import { env } from '../env.js';
import { decryptSecret } from '../utils/crypto.js';

export type NormalizedMetric = {
  date: Date;
  campaignExternalId: string;
  campaignName: string;
  campaignStatus?: string;
  impressions: number;
  reach: number;
  clicks: number;
  spend: number;
  conversions: number;
  ctr: number;
  cpc: number;
  cpm: number;
  roas: number;
  rawJson: unknown;
};

export async function fetchMetaCampaignInsights(params: {
  encryptedAccessToken?: string | null;
  adAccountId: string;
  from: string;
  to: string;
}): Promise<NormalizedMetric[]> {
  const accessToken = decryptSecret(params.encryptedAccessToken);
  if (!accessToken) throw new Error('Access token Meta ausente.');

  const fields = [
    'campaign_id',
    'campaign_name',
    'impressions',
    'reach',
    'clicks',
    'spend',
    'ctr',
    'cpc',
    'cpm',
    'actions',
    'date_start'
  ].join(',');

  const account = params.adAccountId.startsWith('act_') ? params.adAccountId : `act_${params.adAccountId}`;
  const url = `https://graph.facebook.com/${env.META_GRAPH_VERSION}/${account}/insights`;

  const response = await axios.get(url, {
    params: {
      access_token: accessToken,
      level: 'campaign',
      fields,
      time_increment: 1,
      time_range: JSON.stringify({ since: params.from, until: params.to })
    }
  });

  return (response.data?.data || []).map((row: any) => {
    const conversions = Number((row.actions || []).find((a: any) => String(a.action_type).includes('lead'))?.value || 0);
    const spend = Number(row.spend || 0);
    return {
      date: new Date(row.date_start),
      campaignExternalId: String(row.campaign_id),
      campaignName: row.campaign_name || 'Campanha sem nome',
      campaignStatus: undefined,
      impressions: Number(row.impressions || 0),
      reach: Number(row.reach || 0),
      clicks: Number(row.clicks || 0),
      spend,
      conversions,
      ctr: Number(row.ctr || 0),
      cpc: Number(row.cpc || 0),
      cpm: Number(row.cpm || 0),
      roas: spend > 0 ? Number(((conversions * 35) / spend).toFixed(4)) : 0,
      rawJson: row
    };
  });
}

export function providerMeta() {
  return Provider.META;
}

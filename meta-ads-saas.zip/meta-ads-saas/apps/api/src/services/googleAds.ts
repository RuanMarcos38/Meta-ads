import axios from 'axios';
import { Provider } from '@prisma/client';
import { env } from '../env.js';
import { decryptSecret } from '../utils/crypto.js';
import type { NormalizedMetric } from './metaAds.js';

async function refreshGoogleAccessToken(refreshToken: string) {
  const response = await axios.post('https://oauth2.googleapis.com/token', new URLSearchParams({
    client_id: env.GOOGLE_ADS_CLIENT_ID,
    client_secret: env.GOOGLE_ADS_CLIENT_SECRET,
    refresh_token: refreshToken,
    grant_type: 'refresh_token'
  }));
  return response.data.access_token as string;
}

export async function fetchGoogleCampaignInsights(params: {
  encryptedRefreshToken?: string | null;
  customerId: string;
  from: string;
  to: string;
}): Promise<NormalizedMetric[]> {
  const refreshToken = decryptSecret(params.encryptedRefreshToken);
  if (!refreshToken) throw new Error('Refresh token Google Ads ausente.');

  const accessToken = await refreshGoogleAccessToken(refreshToken);
  const customerId = params.customerId.replace(/-/g, '');
  const query = `
    SELECT
      campaign.id,
      campaign.name,
      campaign.status,
      segments.date,
      metrics.impressions,
      metrics.clicks,
      metrics.cost_micros,
      metrics.conversions,
      metrics.ctr,
      metrics.average_cpc
    FROM campaign
    WHERE segments.date BETWEEN '${params.from}' AND '${params.to}'
    ORDER BY segments.date DESC
  `;

  const response = await axios.post(
    `https://googleads.googleapis.com/v18/customers/${customerId}/googleAds:searchStream`,
    { query },
    {
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'developer-token': env.GOOGLE_ADS_DEVELOPER_TOKEN,
        ...(env.GOOGLE_ADS_LOGIN_CUSTOMER_ID ? { 'login-customer-id': env.GOOGLE_ADS_LOGIN_CUSTOMER_ID.replace(/-/g, '') } : {})
      }
    }
  );

  const chunks = Array.isArray(response.data) ? response.data : [];
  const rows = chunks.flatMap((chunk: any) => chunk.results || []);
  return rows.map((row: any) => {
    const spend = Number(row.metrics?.costMicros || 0) / 1_000_000;
    const clicks = Number(row.metrics?.clicks || 0);
    const impressions = Number(row.metrics?.impressions || 0);
    const conversions = Number(row.metrics?.conversions || 0);
    return {
      date: new Date(row.segments?.date),
      campaignExternalId: String(row.campaign?.id),
      campaignName: row.campaign?.name || 'Campanha sem nome',
      campaignStatus: row.campaign?.status,
      impressions,
      reach: 0,
      clicks,
      spend,
      conversions,
      ctr: Number(row.metrics?.ctr || 0) * 100,
      cpc: clicks ? spend / clicks : 0,
      cpm: impressions ? (spend / impressions) * 1000 : 0,
      roas: spend > 0 ? Number(((conversions * 35) / spend).toFixed(4)) : 0,
      rawJson: row
    };
  });
}

export function providerGoogle() {
  return Provider.GOOGLE;
}
